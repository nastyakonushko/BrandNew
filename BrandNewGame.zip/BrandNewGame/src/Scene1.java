import org.newdawn.slick.Color;
import org.newdawn.slick.GameContainer;
import org.newdawn.slick.Graphics;
import org.newdawn.slick.Input;
import org.newdawn.slick.SlickException;
import org.newdawn.slick.tiled.TiledMap;


public class Scene1 extends Scene 
{
	private TiledMap map;
	
	private int x;
	private int y;
	
	public Scene1 () {
		super();
		setPriority(1);
	}
	
	protected void CustomRender(GameContainer gc, Graphics g) throws SlickException 
	{
		map.render(0, 0);
		
		g.fillRect(x * 32, y * 32, 32, 32);
	}
	
	protected void CustomUpdate(GameContainer gc, int t) throws SlickException 
	{
		int objectLayer = map.getLayerIndex("Objects");
		
		map.getTileId(0, 0, objectLayer);
		
		if(gc.getInput().isKeyPressed(Input.KEY_RIGHT)) {
			if(map.getTileId(x + 1, y, objectLayer) == 0) {
			 x++;
			}
		}
		
		if(gc.getInput().isKeyPressed(Input.KEY_LEFT)) {
			if(map.getTileId(x - 1, y, objectLayer) == 0) {
			 x--;
			}
		}
		
		if(gc.getInput().isKeyPressed(Input.KEY_DOWN)) {
			if(map.getTileId(x, y + 1, objectLayer) == 0) {
			 y++;
			}
		}
		
		if(gc.getInput().isKeyPressed(Input.KEY_UP)) {
			if(map.getTileId(x, y - 1, objectLayer) == 0) {
			 y--;
			}
		}
	}
	
	public void init(GameContainer gc) throws SlickException 
	{
		map = new TiledMap("res/desertmap.tmx");
		x = 100;
		y = 100;
	}
	
	public String toString()
	{
		return "Sence1";
	}
}
