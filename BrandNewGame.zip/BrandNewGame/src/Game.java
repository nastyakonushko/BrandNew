import java.util.Iterator;
import java.util.LinkedList;
import java.util.Random;

import org.newdawn.slick.*;
import org.newdawn.slick.geom.Vector2f;
import org.newdawn.slick.tiled.TiledMap;

public class Game extends BasicGame {
	
	private TiledMap map;
	private Music ambientMusic;
	private Sound stepSound;
	
	private int x,y;
//	private int mapX, mapY = 0;
	
//	private LinkedList<Bullet> bullets;
//	public static SceneManager manager;
		
	@Override
	public void render (GameContainer gc, Graphics g) throws SlickException {
		
		map.render(0, 0);

//		manager.render(gc, g);
		
		g.setColor(Color.white);
		g.fillOval(x*32, y*32, 32, 32);
//		
//		for( Bullet b : bullets) {
//			b.render(gc, g);			 
//		}
	}
	
	@Override 
	public void update (GameContainer gc, int t) throws SlickException {		
//		manager.update(gc, t);
		
		int objectLayer = map.getLayerIndex("collision");
		
//		map.getTileId(0, 0, objectLayer);
		
		if(gc.getInput().isKeyPressed(Input.KEY_RIGHT)) {
			if(map.getTileId(x + 1, y, objectLayer) == 0) {
			 x++;
			 stepSound.play();
			}
//			x -= t/3.0f;
		}
		
		if(gc.getInput().isKeyPressed(Input.KEY_LEFT)) {
			if(map.getTileId(x - 1, y, objectLayer) == 0) {
			 x--;
			 stepSound.play();
			}
//			x += t/3.0f;
		}
		
		if(gc.getInput().isKeyPressed(Input.KEY_DOWN)) {
			if(map.getTileId(x, y + 1, objectLayer) == 0) {
			 y++;
			 stepSound.play();
			}
//			y -= t/3.0f;
		}
		
		if(gc.getInput().isKeyPressed(Input.KEY_UP)) {
			if(map.getTileId(x, y - 1, objectLayer) == 0) {
			 y--;
			 stepSound.play();
			}
//			y += t/3.0f;
		}
		
//		if (x < 0) {
//			mapX++;
//			x = 32;
//		}
//		
//		if (x > 32) {
//			mapX--;
//			x = 0;
//		}
//		
//		if (y < 0) {
//			mapY++;
//			y = 32;
//		}
//		
//		if (y > 32) {
//			mapY--;
//			y = 0;
//		}
//				
//		Iterator<Bullet> i = bullets.iterator();
//		while(i.hasNext()) {
//			Bullet b = i.next();
//			if(b.isActive()) {
//				b.update(t);
//			} else {
//				i.remove();
//			}
//			b.update(t);
//		}
//		
//		if(gc.getInput().isKeyPressed(Input.KEY_SPACE)) {
//			bullets.add(new Bullet(new Vector2f(100,100), new Vector2f(300, 50)));
//		}
	}
	
	@Override
	public void init (GameContainer gc) throws SlickException { // ������ ���������/���������������� png � init(), � �� � render()
		
		map = new TiledMap("res/desertmap.tmx");
		
		x = 14;
		y = 22;
		
		ambientMusic = new Music("res/wind2.ogg");
		ambientMusic.setVolume(0.5f);
		ambientMusic.loop();
		stepSound = new Sound("res/hit.ogg");	
		
//		bullets = new LinkedList<Bullet>();
//		manager = new SceneManager(gc);
//		manager.addSence(new Scene1 ());
//		manager.addSence(new Scene2 ());
	}
	
	public Game() {
		super("Brand New Game");
	}
}
