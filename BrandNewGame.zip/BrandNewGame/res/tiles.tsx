<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.4" name="tiles" tilewidth="32" tileheight="32" tilecount="300" columns="20">
 <image source="tiles.png" width="640" height="480"/>
</tileset>
